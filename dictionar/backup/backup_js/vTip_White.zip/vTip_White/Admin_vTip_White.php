<?php
defined('is_running') or die('Not an entry point...');


class Admin_vTip_White{
	function Admin_vTip_White(){ 
		echo '<h2>
	gpEasy vTip Plugin</h2>
<p>
	This is a very simple and light weight plugin that adds a gadget to gpEasy CMS that will style all anchor titles with a custom tool tip. Apply this gadget to any layout in which you want your anchor titles to be displayed with the vTip style.</p>
	<p>
	Plugin home page: <a title="Go to the plugin home page for docs and more info" target="_blank" href="http://trueacu.com/Plugins_vTip">gpEasy vTip Plugin Home Page</a></p>
';
		
	}
}
	

