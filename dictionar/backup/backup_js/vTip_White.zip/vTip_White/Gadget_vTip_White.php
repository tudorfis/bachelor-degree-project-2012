<?php defined('is_running') or die('Not an entry point...');
if (strpos($_SERVER['REQUEST_URI'],'/Admin')===false) //if login page was not requested
{
		global $addonFolderName,$page;
		$page->head_js[] = '/data/_addoncode/'.$addonFolderName.'/vtip.js';
		$page->css_user[] =  '/data/_addoncode/'.$addonFolderName.'/style.css';
}